import os
import sys
os.environ["PYSPARK_PYTHON"] = "/opt/cloudera/parcels/Anaconda/bin/python"
os.environ["JAVA_HOME"] = "/usr/java/jdk1.8.0_232-cloudera/jre"
os.environ["SPARK_HOME"]="/opt/cloudera/parcels/SPARK2-2.3.0.cloudera2-1.cdh5.13.3.p0.316101/lib/spark2/"
os.environ["PYLIB"] = os.environ["SPARK_HOME"] + "/python/lib"
sys.path.insert(0, os.environ["PYLIB"] +"/py4j-0.10.6-src.zip")
sys.path.insert(0, os.environ["PYLIB"] +"/pyspark.zip")

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('jupyter_Spark').master("local").getOrCreate()
spark

df = spark.read.csv("/user/root/SRC_ATM_TRANS/part-m-00000", header = False, inferSchema = True)

df.show(1)

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, BooleanType, DoubleType, LongType

Schema = StructType([StructField('year', IntegerType(), nullable = True),
                        StructField('month', StringType(), True),
                        StructField('day', IntegerType(), True),
                        StructField('weekday', StringType(), True),
                        StructField('hour', IntegerType(), True),
                        StructField('atm_status', StringType(), True),
                        StructField('atm_id', StringType(), True),
                        StructField('atm_manufacturer', StringType(), True),
                        StructField('atm_location', StringType(), True),
                        StructField('atm_streetname', StringType(), True),
                        StructField('atm_street_number', IntegerType(), True),
                        StructField('atm_zipcode', IntegerType(), True),
                        StructField('atm_lat', DoubleType(), True),
                        StructField('atm_lon', DoubleType(), True),
                        StructField('currency', StringType(), True),
                        StructField('card_type', StringType(), True),
                        StructField('transaction_amount', IntegerType(), True),
                        StructField('service', StringType(), True),
                        StructField('message_code', StringType(), True),
                        StructField('message_text', StringType(), True),
                        StructField('weather_lat', DoubleType(), True),
                        StructField('weather_lon', DoubleType(), True),
                        StructField('weather_city_id', IntegerType(), True),
                        StructField('weather_city_name', StringType(), True),
                        StructField('temp', DoubleType(), True),
                        StructField('pressure', IntegerType(), True),
                        StructField('humidity', IntegerType(), True),
                        StructField('wind_speed', IntegerType(), True),
                        StructField('wind_deg', IntegerType(), True),
                        StructField('rain_3h', DoubleType(), True),
                        StructField('clouds_all', IntegerType(), True),
                        StructField('weather_id', IntegerType(), True),
                        StructField('weather_main', StringType(), True),
                        StructField('weather_description', StringType(), True)])

df = spark.read.csv("/user/root/SRC_ATM_TRANS/part-m-00000", header = False, schema = Schema)

df.select('*').count()

df.printSchema()

df.show(1)

df.columns

# creating a temporary df and selecting required columns & making sure records are distinct

location = df.select('atm_location', 'atm_streetname', 'atm_street_number', 'atm_zipcode', 'atm_lat', 'atm_lon').distinct()

from pyspark.sql.functions import *

# creating the primary key column

df_temp = location.rdd.zipWithIndex().toDF()
dim_location = df_temp.select(col("_1.*"),col("_2").alias('location_id'))
dim_location.show(5)

# renaming the colums as per requirement

DIM_LOCATION = dim_location.withColumnRenamed('atm_location','location').withColumnRenamed('atm_streetname','streetname').withColumnRenamed('atm_street_number','street_number').withColumnRenamed('atm_zipcode','zipcode').withColumnRenamed('atm_lat','lat').withColumnRenamed('atm_lon','lon')

# rearranging the columns according to the target model

DIM_LOCATION = DIM_LOCATION.select('location_id', 'location', 'streetname', 'street_number', 'zipcode', 'lat', 'lon')

# checking that all required columns are present and named correctly

DIM_LOCATION.columns

# validating the count of the dataframe

DIM_LOCATION.select('*').count()

# creating a temporary df and selecting required columns

atm = df.select('atm_id', 'atm_manufacturer', 'atm_lat', 'atm_lon')

# renaming the column atm_id to atm_number as per requirement

atm = atm.withColumnRenamed('atm_id', 'atm_number')

# joining the dim_location and atm dataframes

atm = atm.join(dim_location, on = ['atm_lat', 'atm_lon'], how = "left")

# checking to columns in the joined df

atm.columns

# selecting the required columns and making sure records are distinct

atm = atm.select('atm_number', 'atm_manufacturer', 'location_id').distinct()

# renaming the colums as per requirement

atm = atm.withColumnRenamed('location_id', 'atm_location_id')

# viewing changes in columns

atm.columns

# creating the primary key column

df_temp = atm.rdd.zipWithIndex().toDF()
dim_atm = df_temp.select(col("_1.*"),col("_2").alias('atm_id'))
dim_atm.show(5)

# rearranging the columns according to the target model

DIM_ATM = dim_atm.select('atm_id', 'atm_number', 'atm_manufacturer', 'atm_location_id')

# checking that all required columns are present and named correctly

DIM_ATM.columns

# validating the count of the dataframe

DIM_ATM.select('*').count()

# creating a temporary df and selecting required columns

date = df.select('year', 'month', 'day', 'hour', 'weekday')

date = date.withColumn('full_date', concat_ws('-', date.year, date.month, date.day))

date = date.withColumn('full_time', concat_ws(':', date.hour, lit('00'), lit('00')))

date = date.withColumn('full_date_time', concat_ws(' ', date.full_date, date.full_time))

# selecting the required columns and making sure records are distinct

date = date.select('year', 'month', 'day', 'hour', 'weekday', 'full_date_time').distinct()

from pyspark.sql.functions import monotonically_increasing_id

DIM_DATE=date.withColumn("date_id", monotonically_increasing_id())

DIM_DATE.show()

# rearranging the columns according to the target model

DIM_DATE = DIM_DATE.select('date_id', 'full_date_time', 'year', 'month', 'day', 'hour', 'weekday')

# checking that all required columns are present and named correctly

DIM_DATE.columns

# validating the count of the dataframe

DIM_DATE.select('*').count()

# creating a temporary df and selecting required columns and making sure records are distinct

card_type = df.select('card_type').distinct()

# creating the primary key column

df_temp = card_type.rdd.zipWithIndex().toDF()
DIM_CARD_TYPE = df_temp.select(col("_1.*"),col("_2").alias('card_type_id'))
DIM_CARD_TYPE.show(5)

# rearranging the columns according to the target model

DIM_CARD_TYPE = DIM_CARD_TYPE.select('card_type_id', 'card_type')

# checking that all required columns are present and named correctly

DIM_CARD_TYPE.columns

# validating the count of the dataframe

DIM_CARD_TYPE.select('*').count()

# Stage 1 of FACT_ATM_TRANS Table -> joining original dataframe with DIM_LOC

# renaming the colums as per requirement

fact_loc = df.withColumnRenamed('atm_location','location').withColumnRenamed('atm_streetname','streetname').withColumnRenamed('atm_street_number','street_number').withColumnRenamed('atm_zipcode','zipcode').withColumnRenamed('atm_lat','lat').withColumnRenamed('atm_lon','lon')

# joining the dfs

fact_loc = fact_loc.join(DIM_LOCATION, on = ['location', 'streetname', 'street_number', 'zipcode', 'lat', 'lon'], how = "left")

# viewing the columns

fact_loc.columns

# Validating the count of the df at the end of Stage 1

fact_loc.select('*').count()

# Stage 2 of FACT_ATM_TRANS Table -> joining the dataframe with DIM_ATM

# renaming the colums as per requirement

fact_loc = fact_loc.withColumnRenamed('atm_id', 'atm_number').withColumnRenamed('location_id', 'atm_location_id')

# joining the dfs

fact_atm = fact_loc.join(DIM_ATM, on = ['atm_number', 'atm_manufacturer', 'atm_location_id'], how = "left")

# performing necessary transformations, same as done to atm table

fact_atm = fact_atm.withColumnRenamed('atm_location_id', 'weather_loc_id')

# Validating the count of the df at the end of Stage 2

fact_atm.select('*').count()

# Stage 3 of FACT_ATM_TRANS Table -> joining the dataframe with DIM_DATE

# joining the dfs

fact_date = fact_atm.join(DIM_DATE, on = ['year', 'month', 'day', 'hour', 'weekday'], how = "left")

# Validating the count of the df at the end of Stage 3

fact_date.select('*').count()

# Stage 4 of FACT_ATM_TRANS Table -> joining the dataframe with DIM_CARD_TYPE

# joining the dfs

fact_atm_trans = fact_date.join(DIM_CARD_TYPE, on = ['card_type'], how = "left")

# Validating the count of the df at the end of Stage 4

fact_atm_trans.select('*').count()

# creating primary key of fact table and viewing 1st record of the table

from pyspark.sql.window import Window

w = Window().orderBy('date_id')
FACT_ATM_TRANS = fact_atm_trans.withColumn("trans_id", row_number().over(w))
FACT_ATM_TRANS.show(1, True)

# viewing the list of columns

FACT_ATM_TRANS.columns

# selecting and arranging only the required columns according to the target model

FACT_ATM_TRANS = FACT_ATM_TRANS.select('trans_id', 'atm_id', 'weather_loc_id', 'date_id', 'card_type_id', 
'atm_status', 'currency', 'service', 'transaction_amount', 'message_code', 'message_text', 'rain_3h', 
'clouds_all', 'weather_id', 'weather_main', 'weather_description')

# checking that all required columns are present and named correctly

FACT_ATM_TRANS.columns

# validating the count of the dataframe

FACT_ATM_TRANS.select('*').count()

# writing data from pyspark df 'DIM_LOCATION' in csv format to dim_location folder in S3 bucket 'aneesaetlbucket'

DIM_LOCATION.coalesce(1).write.format('csv').option('header','false').save('s3://aneesaetlbucket/dim_location/', mode='overwrite')

# writing data from pyspark df 'DIM_ATM' in csv format to dim_atm folder in S3 bucket 'aneesaetlbucket'

DIM_ATM.coalesce(1).write.format('csv').option('header','false').save('s3://aneesaetlbucket/dim_atm/', mode='overwrite')

# writing data from pyspark df 'DIM_DATE' in csv format to dim_date folder in S3 bucket 'aneesaetlbucket'

DIM_DATE.coalesce(1).write.format('csv').option('header','false').save('s3://aneesaetlbucket/dim_date/', mode='overwrite')

# writing data from pyspark df 'DIM_CARD_TYPE' in csv format to dim_card_type folder in S3 bucket 'aneesaetlbucket'

DIM_CARD_TYPE.coalesce(1).write.format('csv').option('header','false').save('s3://aneesaetlbucket/dim_card_type/', mode='overwrite')

# writing data from pyspark df 'FACT_ATM_TRANS' in csv format to fact_atm_trans folder in S3 bucket 'aneesaetlbucket'

FACT_ATM_TRANS.coalesce(1).write.format('csv').option('header','false').save('s3://aneesaetlbucket/fact_atm_trans/', mode='overwrite')


